const express = require('express')
const loginRouter = express.Router()
const user = require('../models/user')






module.exports =loginRouter;
